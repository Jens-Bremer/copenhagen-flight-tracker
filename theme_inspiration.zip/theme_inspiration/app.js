/**
 * Bar Stats Dashboard — vanilla-JS frontend.
 *
 * Loads master_data.csv (transactions) and rekeningen.csv (name lookup) sitting
 * next to index.html. Aggregates the season's high-BTW drink consumption per
 * personal card, then populates the DOM produced by the designer.
 *
 * Pipeline: password gate (data fetched in parallel) → parse (PapaParse) →
 *           qualify rows → single-pass aggregate → render (Chart.js for charts,
 *           plain DOM for the rest). Clicking a leaderboard name switches the
 *           hero graph to that card's cumulative line with per-day drink
 *           breakdowns in the tooltip.
 *
 * Season rollover is automatic: `currentSeasonBounds(now)` picks the season
 * containing today, so on the next 1 September the dashboard begins counting
 * from zero against the new season window.
 *
 * No build step. No framework. Run inside a static webserver (or use the
 * file-picker fallback when opened via file://).
 *
 * Authoritative spec: data-contract.md.
 */
(function () {
  'use strict';

  // ───── Constants ────────────────────────────────────────────────────────────

  const EXACT_EXCLUDED_PRODUCTS = new Set(['Omzetgarantie']);
  const PRODUCT_NAME_BLOCKLIST_PATTERNS = [/shot/i];
  const ACCEPTED_CARD_LENGTHS = new Set([3, 5, 13]);
  const SEASON_TARGET_DRINKS = 1000;
  const DAY_BOUNDARY_HOURS = 4;
  const DOUGHNUT_TOP_N = 8;
  const BUSIEST_DRINKS_TOP_N = 10;
  const MASTER_CSV_COLUMN_COUNT = 25;
  const MINUS_SIGN = '\u2212';
  const PASSWORD = 'trekbak';

  const MASTER_CSV_HEADER = [
    'Transactie Id', 'Transactie Guid', 'Datum', 'Betaaltype', 'Terminal',
    'Rekening Id', 'Rekeningnummer', 'Medewerker', 'Te betalen', 'Betaald',
    'Betaald in subtransacties', 'Volledig betaald', 'Korting', 'Product Id', 'Product',
    'Aantal', 'Prijs (per product)', 'Aantal * prijs', 'BTW id', 'BTW Waarde',
    'BTW Type', 'No-sale', 'Sommatieteken', 'Dagboeknummer', 'BTW code'
  ];

  const REQUIRED_DOM_IDS = [
    'season-label', 'last-updated', 'loading-overlay', 'error-banner',
    'cumulative-graph', 'leaderboard-list',
    'card-search-input', 'card-search-button', 'card-stats-panel',
    'card-stats-card-id', 'card-stats-total', 'card-stats-borrels',
    'card-record-wobo', 'card-record-vrimibo',
    'card-distribution-chart', 'card-weekday-chart', 'card-not-found',
    'card-club-1000', 'card-club-expected', 'card-club-deviation', 'card-club-projection',
    'bar-distinct-products', 'bar-total-ordered', 'bar-busiest-list'
  ];

  const WEEKDAY_KEYS = ['mon', 'tue', 'wed', 'thu', 'fri'];
  const WEEKDAY_LABELS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];

  // ───── Module state (kept tiny on purpose) ──────────────────────────────────

  // Populated once aggregation finishes; the only mutable state besides chart
  // instances. Holds everything the UI needs after data is loaded.
  const state = {
    seasonBounds: null,
    today: null,
    aggregated: null,
    selectedCardId: null
  };

  // ───── DOM validation ───────────────────────────────────────────────────────

  /** Throw if any required ID from REQUIRED_DOM_IDS is missing in the document. */
  function assertRequiredDomIds() {
    const missing = REQUIRED_DOM_IDS.filter((id) => !document.getElementById(id));
    if (missing.length > 0) {
      throw new Error('Missing required DOM IDs: ' + missing.join(', '));
    }
  }

  // ───── Date helpers ─────────────────────────────────────────────────────────

  /** Parse "DD-MM-YYYY HH:MM" into a local-time Date. Throw on bad input. */
  function parseDutchDateTime(text) {
    if (typeof text !== 'string') {
      throw new Error('parseDutchDateTime: expected string, got ' + typeof text);
    }
    const match = /^(\d{2})-(\d{2})-(\d{4}) (\d{2}):(\d{2})$/.exec(text);
    if (!match) {
      throw new Error('parseDutchDateTime: bad format: ' + text);
    }
    const day = Number(match[1]);
    const month = Number(match[2]);
    const year = Number(match[3]);
    const hour = Number(match[4]);
    const minute = Number(match[5]);
    return new Date(year, month - 1, day, hour, minute, 0, 0);
  }

  function addHours(date, hours) {
    return new Date(date.getTime() + hours * 3600 * 1000);
  }

  function startOfDay(date) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate());
  }

  function addDays(date, days) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate() + days);
  }

  /**
   * Apply the 04:00 day-boundary shift: a timestamp before 04:00 belongs to
   * the previous calendar day. Returns a Date at 00:00 local time.
   */
  function effectiveDate(timestamp) {
    return startOfDay(addHours(timestamp, -DAY_BOUNDARY_HOURS));
  }

  /** "2025-09-01" — used as a stable map key. */
  function isoDateKey(date) {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, '0');
    const d = String(date.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  /** "1 Sep 2025" — for human-facing labels. */
  function formatHumanDate(date) {
    return new Intl.DateTimeFormat('en-GB', {
      day: 'numeric', month: 'short', year: 'numeric'
    }).format(date);
  }

  /** "26 Apr 2026 13:00" — for the "data through" header. */
  function formatHumanDateTime(date) {
    const d = new Intl.DateTimeFormat('en-GB', {
      day: 'numeric', month: 'short', year: 'numeric'
    }).format(date);
    const t = String(date.getHours()).padStart(2, '0') + ':' +
              String(date.getMinutes()).padStart(2, '0');
    return `${d} ${t}`;
  }

  /** Inclusive whole-day count from `from` (00:00) to `to` (00:00). */
  function daysBetweenInclusive(from, to) {
    const ms = startOfDay(to).getTime() - startOfDay(from).getTime();
    return Math.round(ms / (24 * 3600 * 1000)) + 1;
  }

  function parseIsoDateKey(key) {
    const [y, m, d] = key.split('-').map(Number);
    return new Date(y, m - 1, d);
  }

  /**
   * Longest run of consecutive same-weekday attendances (each entry exactly
   * 7 days after the previous). Used for "longest WoBo streak" (Wed) and
   * "longest VriMiBo streak" (Fri). Returns weeks, not days.
   */
  function longestWeeklyStreak(dateKeySet) {
    if (!dateKeySet || dateKeySet.size === 0) return 0;
    const sorted = Array.from(dateKeySet).sort();
    let longest = 1;
    let current = 1;
    for (let i = 1; i < sorted.length; i++) {
      const prev = parseIsoDateKey(sorted[i - 1]);
      const curr = parseIsoDateKey(sorted[i]);
      const diffDays = Math.round((curr.getTime() - prev.getTime()) / (24 * 3600 * 1000));
      if (diffDays === 7) {
        current++;
        if (current > longest) longest = current;
      } else {
        current = 1;
      }
    }
    return longest;
  }

  // ───── Season helpers ───────────────────────────────────────────────────────

  /**
   * Return { start, endInclusive, label } for the season that contains `now`.
   * Season runs Sep 1 (year Y) → Aug 31 (year Y+1). Before Sep, current season
   * started the previous year. This is what makes the dashboard self-roll on
   * 1 September every year.
   */
  function currentSeasonBounds(now) {
    const startYear = now.getMonth() >= 8 ? now.getFullYear() : now.getFullYear() - 1;
    const start = new Date(startYear, 8, 1);                   // Sep 1
    const endInclusive = new Date(startYear + 1, 7, 31);       // Aug 31 next year
    const label = `${startYear}\u2013${startYear + 1}`;
    return { start, endInclusive, label };
  }

  // ───── CSV parsing ──────────────────────────────────────────────────────────

  /**
   * Parse master_data.csv. The vendor's export glues an HTML blob onto the
   * header line, so we ignore the file's header entirely and use a fixed
   * 25-column schema (see contract §2).
   */
  function parseMasterData(csvText) {
    if (typeof Papa === 'undefined') {
      throw new Error('PapaParse is not loaded.');
    }
    const result = Papa.parse(csvText, {
      delimiter: ';',
      skipEmptyLines: true,
      header: false
    });
    if (result.errors && result.errors.length > 0) {
      console.warn(`[parseMasterData] ${result.errors.length} row-level CSV warnings`);
    }
    const dataRows = result.data.slice(1); // drop the corrupted header line
    const rows = [];
    for (let i = 0; i < dataRows.length; i++) {
      const fields = dataRows[i];
      if (fields.length === 0) continue;
      const row = {};
      for (let c = 0; c < MASTER_CSV_COLUMN_COUNT; c++) {
        row[MASTER_CSV_HEADER[c]] = fields[c];
      }
      rows.push(row);
    }
    return rows;
  }

  /**
   * Parse rekeningen.csv into a Map<lookup_key, displayName>. The lookup_key
   * is the bare Rekeningnummer (3 or 5 digits for short cards, "2"+last4 for
   * 13-digit cards). Names are .trim()-ed.
   */
  function parseRekeningenIntoNameMap(csvText) {
    const result = Papa.parse(csvText, {
      delimiter: ';',
      skipEmptyLines: true,
      header: true
    });
    const nameMap = new Map();
    for (const row of result.data) {
      const number = (row['Rekeningnummer'] || '').trim();
      const name = (row['Beschrijving'] || '').trim();
      if (number && name) {
        nameMap.set(number, name);
      }
    }
    return nameMap;
  }

  /**
   * Find the latest valid Datum across every row in the CSV (qualifying or
   * not). This becomes the "data through ..." header value, so the user
   * always sees how fresh their data is, not when the page was loaded.
   */
  function findLatestDataTimestamp(rows) {
    let latest = null;
    for (const row of rows) {
      const datum = row['Datum'];
      if (!datum) continue;
      let ts;
      try {
        ts = parseDutchDateTime(datum);
      } catch (_e) {
        continue;
      }
      if (!latest || ts > latest) latest = ts;
    }
    return latest;
  }

  // ───── Display label resolution ─────────────────────────────────────────────

  function normalizeRawNumber(rawValue) {
    return String(rawValue || '').replace('.0', '');
  }

  /**
   * Resolve a card identifier to its human-facing display label.
   * Length 3 and 5 → exact match in nameMap, fallback to the bare number.
   * Length 13 → "2" + last4 lookup, fallback to "•••• 1234".
   */
  function buildDisplayLabel(rawNumber, nameMap) {
    const raw = normalizeRawNumber(rawNumber);
    let lookupKey;
    if (raw.length === 3 || raw.length === 5) {
      lookupKey = raw;
    } else if (raw.length === 13) {
      lookupKey = '2' + raw.slice(-4);
    } else {
      throw new Error('buildDisplayLabel: unexpected card length: ' + raw);
    }
    const name = nameMap.get(lookupKey);
    if (name) {
      return name;
    }
    if (raw.length === 13) {
      return '\u2022\u2022\u2022\u2022 ' + raw.slice(-4);
    }
    return raw;
  }

  // ───── Product blocklist ────────────────────────────────────────────────────

  /** Combined exact-match + pattern-match check (e.g. anything with "shot"). */
  function isBlockedProduct(product) {
    if (!product) return true;
    if (EXACT_EXCLUDED_PRODUCTS.has(product)) return true;
    for (const pattern of PRODUCT_NAME_BLOCKLIST_PATTERNS) {
      if (pattern.test(product)) return true;
    }
    return false;
  }

  // ───── Row qualification ────────────────────────────────────────────────────

  /**
   * A row qualifies for stats iff it is high-BTW, has a 3/5/13-digit card,
   * isn't a blocked product, and falls in the current season.
   */
  function makeQualifier(seasonStart) {
    return function qualifies(row) {
      if (row['BTW Type'] !== 'Hoog') return false;
      if (isBlockedProduct(row['Product'])) return false;
      const raw = normalizeRawNumber(row['Rekeningnummer']);
      if (!ACCEPTED_CARD_LENGTHS.has(raw.length)) return false;
      const datum = row['Datum'];
      if (!datum) return false;
      let timestamp;
      try {
        timestamp = parseDutchDateTime(datum);
      } catch (_e) {
        return false;
      }
      if (timestamp < seasonStart) return false;
      // Stash parsed values onto the row so aggregation doesn't reparse.
      row.__timestamp = timestamp;
      row.__cardId = raw;
      row.__quantity = Number(row['Aantal']) || 0;
      return row.__quantity > 0;
    };
  }

  // ───── Aggregation ──────────────────────────────────────────────────────────

  /**
   * Single-pass aggregator. Walks qualifying rows once and returns the
   * complete data object described in contract §3, plus per-card daily
   * breakdowns used by the per-card cumulative graph.
   */
  function aggregateAll(rows, seasonStart, today, nameMap) {
    const drinksPerDay = new Map();
    const cardAccumulators = new Map();
    const drinksPerProduct = new Map();
    const distinctProducts = new Set();
    let totalDrinks = 0;

    for (const row of rows) {
      const eff = effectiveDate(row.__timestamp);
      const dayKey = isoDateKey(eff);
      const quantity = row.__quantity;
      const cardId = row.__cardId;
      const product = row['Product'];

      drinksPerDay.set(dayKey, (drinksPerDay.get(dayKey) || 0) + quantity);
      drinksPerProduct.set(product, (drinksPerProduct.get(product) || 0) + quantity);
      distinctProducts.add(product);
      totalDrinks += quantity;

      let card = cardAccumulators.get(cardId);
      if (!card) {
        card = {
          card_id: cardId,
          total_drinks: 0,
          productCounts: new Map(),
          weekdayDates: [new Set(), new Set(), new Set(), new Set(), new Set()],
          attendedDates: new Set(),
          dailyBreakdown: new Map() // dayKey -> Map<product, count>
        };
        cardAccumulators.set(cardId, card);
      }
      card.total_drinks += quantity;
      card.productCounts.set(product, (card.productCounts.get(product) || 0) + quantity);

      let perDay = card.dailyBreakdown.get(dayKey);
      if (!perDay) {
        perDay = new Map();
        card.dailyBreakdown.set(dayKey, perDay);
      }
      perDay.set(product, (perDay.get(product) || 0) + quantity);

      const dayOfWeek = eff.getDay(); // 0=Sun..6=Sat
      if (dayOfWeek >= 1 && dayOfWeek <= 5) {
        card.weekdayDates[dayOfWeek - 1].add(dayKey);
        card.attendedDates.add(dayKey);
      }
    }

    return {
      meta: {
        season_label: '',
        season_start: isoDateKey(seasonStart),
        total_qualifying_rows: rows.length
      },
      daily_totals: buildDailyTotals(drinksPerDay, seasonStart, today),
      leaderboard: buildLeaderboard(cardAccumulators, nameMap),
      cards: buildCards(cardAccumulators, nameMap, seasonStart, today),
      bar_overview: {
        distinct_high_btw_products: distinctProducts.size,
        total_drinks_ordered: totalDrinks,
        busiest_drinks: buildBusiestDrinks(drinksPerProduct)
      }
    };
  }

  /** Bar-wide daily_totals. One entry per calendar day (zero-days included). */
  function buildDailyTotals(drinksPerDay, seasonStart, today) {
    const out = [];
    let cumulative = 0;
    const todayDay = startOfDay(today);
    let cursor = startOfDay(seasonStart);
    while (cursor <= todayDay) {
      const key = isoDateKey(cursor);
      const drinksThatDay = drinksPerDay.get(key) || 0;
      cumulative += drinksThatDay;
      out.push({ date: key, drinks_that_day: drinksThatDay, cumulative });
      cursor = addDays(cursor, 1);
    }
    return out;
  }

  function buildLeaderboard(cardAccumulators, nameMap) {
    const all = [];
    for (const card of cardAccumulators.values()) {
      all.push({
        card_id: card.card_id,
        display_label: buildDisplayLabel(card.card_id, nameMap),
        total_drinks: card.total_drinks
      });
    }
    all.sort((a, b) => {
      if (b.total_drinks !== a.total_drinks) return b.total_drinks - a.total_drinks;
      return a.card_id.localeCompare(b.card_id);
    });
    for (let i = 0; i < all.length; i++) {
      all[i].rank = i + 1;
    }
    return all;
  }

  function buildCards(cardAccumulators, nameMap, seasonStart, today) {
    const out = {};
    for (const card of cardAccumulators.values()) {
      const distribution = [];
      for (const [product, count] of card.productCounts.entries()) {
        distribution.push({ product, count });
      }
      distribution.sort((a, b) => b.count - a.count);

      const weekdayAttendance = {};
      for (let i = 0; i < WEEKDAY_KEYS.length; i++) {
        weekdayAttendance[WEEKDAY_KEYS[i]] = card.weekdayDates[i].size;
      }

      out[card.card_id] = {
        card_id: card.card_id,
        display_label: buildDisplayLabel(card.card_id, nameMap),
        total_drinks: card.total_drinks,
        drink_distribution: distribution,
        weekday_attendance: weekdayAttendance,
        borrels_attended: card.attendedDates.size,
        longest_wobo_streak: longestWeeklyStreak(card.weekdayDates[2]),     // Wednesday
        longest_vrimibo_streak: longestWeeklyStreak(card.weekdayDates[4]),  // Friday
        daily_totals: buildCardDailyTotals(card.dailyBreakdown, seasonStart, today)
      };
    }
    return out;
  }

  /**
   * Per-card daily totals with a `breakdown` array on every non-empty day.
   * Used by the per-card cumulative graph and its rich tooltip.
   */
  function buildCardDailyTotals(dailyBreakdown, seasonStart, today) {
    const out = [];
    let cumulative = 0;
    const todayDay = startOfDay(today);
    let cursor = startOfDay(seasonStart);
    while (cursor <= todayDay) {
      const key = isoDateKey(cursor);
      const perDay = dailyBreakdown.get(key);
      let drinksThatDay = 0;
      let breakdown = null;
      if (perDay) {
        breakdown = [];
        for (const [product, count] of perDay.entries()) {
          breakdown.push({ product, count });
          drinksThatDay += count;
        }
        breakdown.sort((a, b) => b.count - a.count);
      }
      cumulative += drinksThatDay;
      out.push({ date: key, drinks_that_day: drinksThatDay, cumulative, breakdown });
      cursor = addDays(cursor, 1);
    }
    return out;
  }

  function buildBusiestDrinks(drinksPerProduct) {
    const all = [];
    for (const [product, count] of drinksPerProduct.entries()) {
      all.push({ product, count });
    }
    all.sort((a, b) => b.count - a.count);
    return all.slice(0, BUSIEST_DRINKS_TOP_N);
  }

  // ───── Theme reads ──────────────────────────────────────────────────────────

  function readCssColor(varName) {
    const value = getComputedStyle(document.documentElement).getPropertyValue(varName);
    return value.trim();
  }

  function getThemeColors() {
    return {
      cream: readCssColor('--color-cream'),
      red: readCssColor('--color-red'),
      orange: readCssColor('--color-orange'),
      yellow: readCssColor('--color-yellow'),
      brown: readCssColor('--color-brown'),
      text: readCssColor('--color-text')
    };
  }

  // ───── Charts ───────────────────────────────────────────────────────────────

  const chartRegistry = { cumulative: null, distribution: null, weekday: null };

  function destroyIfExists(slot) {
    if (chartRegistry[slot]) {
      chartRegistry[slot].destroy();
      chartRegistry[slot] = null;
    }
  }

  /**
   * Render the cumulative line. When `dailyTotals` entries carry a `breakdown`
   * field (per-card mode), the tooltip lists products consumed that day.
   */
  function renderCumulativeGraph(dailyTotals, options) {
    const config = options || {};
    const lineColor = config.lineColor || readCssColor('--color-red');
    const fillRgba = config.fillRgba || 'rgba(192, 57, 43, 0.12)';

    const canvas = document.getElementById('cumulative-graph');
    const colors = getThemeColors();
    destroyIfExists('cumulative');

    const labels = dailyTotals.map((d) => d.date);
    const cumulative = dailyTotals.map((d) => d.cumulative);
    const perDay = dailyTotals.map((d) => d.drinks_that_day);
    const breakdowns = dailyTotals.map((d) => d.breakdown || null);

    chartRegistry.cumulative = new Chart(canvas, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Cumulative drinks',
          data: cumulative,
          stepped: 'before',
          borderColor: lineColor,
          backgroundColor: fillRgba,
          borderWidth: 2,
          pointRadius: 0,
          pointHoverRadius: 4,
          pointHoverBackgroundColor: colors.brown,
          fill: true
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: colors.brown,
            titleColor: colors.cream,
            bodyColor: colors.cream,
            borderColor: colors.brown,
            borderWidth: 1,
            padding: 10,
            callbacks: {
              title: (items) => {
                if (!items.length) return '';
                return formatHumanDate(parseIsoDateKey(labels[items[0].dataIndex]));
              },
              label: (item) => {
                const idx = item.dataIndex;
                const lines = [
                  `That day: ${perDay[idx]}`,
                  `Cumulative: ${cumulative[idx]}`
                ];
                const breakdown = breakdowns[idx];
                if (breakdown && breakdown.length > 0) {
                  lines.push('\u2014');
                  for (const b of breakdown) {
                    lines.push(`  ${b.product}  \u00d7${b.count}`);
                  }
                }
                return lines;
              }
            }
          }
        },
        scales: {
          x: {
            ticks: {
              color: colors.brown,
              maxRotation: 0,
              autoSkipPadding: 24,
              callback: function (_value, index) {
                const iso = labels[index];
                if (!iso) return '';
                const d = parseIsoDateKey(iso);
                if (d.getDate() !== 1) return '';
                return new Intl.DateTimeFormat('en-GB', { month: 'short' }).format(d);
              }
            },
            grid: { display: false }
          },
          y: {
            beginAtZero: true,
            ticks: { color: colors.brown },
            grid: { color: 'rgba(107, 62, 38, 0.08)' }
          }
        }
      }
    });
  }

  function renderDistributionChart(distribution) {
    const canvas = document.getElementById('card-distribution-chart');
    const colors = getThemeColors();
    destroyIfExists('distribution');

    const condensed = condenseDistributionForDoughnut(distribution, DOUGHNUT_TOP_N);
    const palette = [
      colors.red, colors.orange, colors.yellow, colors.brown,
      '#8a5a3b', '#a44a2c', '#d4a017', '#5a4632',
      '#b37a4a'
    ];

    chartRegistry.distribution = new Chart(canvas, {
      type: 'doughnut',
      data: {
        labels: condensed.map((s) => s.product),
        datasets: [{
          data: condensed.map((s) => s.count),
          backgroundColor: condensed.map((_s, i) => palette[i % palette.length]),
          borderColor: colors.cream,
          borderWidth: 2
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: colors.text, boxWidth: 12, padding: 8 }
          },
          tooltip: {
            backgroundColor: colors.brown,
            titleColor: colors.cream,
            bodyColor: colors.cream
          }
        },
        cutout: '55%'
      }
    });
  }

  function condenseDistributionForDoughnut(distribution, topN) {
    if (distribution.length <= topN) return distribution.slice();
    const top = distribution.slice(0, topN);
    const otherCount = distribution.slice(topN).reduce((sum, s) => sum + s.count, 0);
    if (otherCount > 0) top.push({ product: 'Other', count: otherCount });
    return top;
  }

  function renderWeekdayChart(weekdayAttendance) {
    const canvas = document.getElementById('card-weekday-chart');
    const colors = getThemeColors();
    destroyIfExists('weekday');
    const data = WEEKDAY_KEYS.map((k) => weekdayAttendance[k] || 0);

    chartRegistry.weekday = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: WEEKDAY_LABELS,
        datasets: [{
          label: 'Days attended',
          data: data,
          backgroundColor: colors.orange,
          borderColor: colors.brown,
          borderWidth: 1
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: colors.brown,
            titleColor: colors.cream,
            bodyColor: colors.cream
          }
        },
        scales: {
          x: { ticks: { color: colors.brown }, grid: { display: false } },
          y: {
            beginAtZero: true,
            ticks: { color: colors.brown, precision: 0, stepSize: 1 },
            grid: { color: 'rgba(107, 62, 38, 0.08)' }
          }
        }
      }
    });
  }

  // ───── Hero graph mode switching (all-bar vs per-card) ──────────────────────

  function setGraphTitle(text) {
    const titleEl = document.querySelector('.graph-panel__title');
    if (titleEl) titleEl.textContent = text;
  }

  function ensureResetButton() {
    let btn = document.getElementById('graph-reset-button');
    if (btn) return btn;
    btn = document.createElement('button');
    btn.id = 'graph-reset-button';
    btn.type = 'button';
    btn.className = 'graph-reset is-hidden';
    btn.textContent = '\u2190 Show all';
    btn.addEventListener('click', renderBarWideHero);
    const panel = document.querySelector('.graph-panel');
    if (panel) panel.appendChild(btn);
    return btn;
  }

  function setResetButtonVisible(visible) {
    const btn = ensureResetButton();
    btn.classList.toggle('is-hidden', !visible);
  }

  function renderBarWideHero() {
    state.selectedCardId = null;
    setGraphTitle(`Cumulative drinks \u2014 season ${state.seasonBounds.label}`);
    setResetButtonVisible(false);
    clearLeaderboardSelection();
    renderCumulativeGraph(state.aggregated.daily_totals, {
      lineColor: readCssColor('--color-red'),
      fillRgba: 'rgba(192, 57, 43, 0.12)'
    });
  }

  function renderPerCardHero(card) {
    state.selectedCardId = card.card_id;
    setGraphTitle(`Cumulative drinks \u2014 ${card.display_label}`);
    setResetButtonVisible(true);
    renderCumulativeGraph(card.daily_totals, {
      lineColor: readCssColor('--color-brown'),
      fillRgba: 'rgba(107, 62, 38, 0.12)'
    });
  }

  // ───── DOM rendering ────────────────────────────────────────────────────────

  /**
   * Show/hide the loading overlay. Inline `important` display defeats the
   * stylesheet's utility-class `!important` (a known designer-side conflict).
   */
  function setLoadingOverlayVisible(visible) {
    const overlay = document.getElementById('loading-overlay');
    if (visible) {
      overlay.classList.add('is-visible');
      overlay.style.setProperty('display', 'flex', 'important');
    } else {
      overlay.classList.remove('is-visible');
      overlay.style.setProperty('display', 'none', 'important');
    }
  }

  function showErrorBanner(message) {
    const banner = document.getElementById('error-banner');
    banner.textContent = message;
    banner.classList.add('is-visible');
  }

  function clearErrorBanner() {
    const banner = document.getElementById('error-banner');
    banner.textContent = '';
    banner.classList.remove('is-visible');
  }

  /**
   * Header meta. The "data through" timestamp comes from the latest row in
   * the CSV, not from the page load time, so the user always sees how fresh
   * the underlying export actually is.
   */
  function renderMeta(bounds, dataTimestamp) {
    document.getElementById('season-label').textContent = `Season ${bounds.label}`;
    const updatedEl = document.getElementById('last-updated');
    if (dataTimestamp) {
      updatedEl.textContent = `Data through ${formatHumanDateTime(dataTimestamp)}`;
    } else {
      updatedEl.textContent = 'Data through \u2014';
    }
  }

  function renderLeaderboard(leaderboard, onRowClick) {
    const ol = document.getElementById('leaderboard-list');
    ol.innerHTML = '';
    for (const entry of leaderboard) {
      const isTop = entry.rank <= 3; // medal styling lives in CSS, but we still tag the row
      ol.appendChild(buildLeaderboardRow(entry, isTop, onRowClick));
    }
  }

  function buildLeaderboardRow(entry, isTop, onRowClick) {
    const li = document.createElement('li');
    li.className = isTop ? 'leaderboard-row leaderboard-row--top' : 'leaderboard-row';
    li.dataset.cardId = entry.card_id;
    li.tabIndex = 0;
    li.setAttribute('role', 'button');
    li.setAttribute('aria-label', `Show stats for ${entry.display_label}`);

    const rank = document.createElement('span');
    rank.className = 'leaderboard-row__rank';
    rank.textContent = String(entry.rank);

    const label = document.createElement('span');
    label.className = 'leaderboard-row__label';
    label.textContent = entry.display_label;

    const count = document.createElement('span');
    count.className = 'leaderboard-row__count';
    count.textContent = formatNumber(entry.total_drinks);

    li.append(rank, label, count);
    li.addEventListener('click', () => onRowClick(entry.card_id));
    li.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        onRowClick(entry.card_id);
      }
    });
    return li;
  }

  function highlightLeaderboardRow(cardId) {
    clearLeaderboardSelection();
    if (!cardId) return;
    const rows = document.querySelectorAll('.leaderboard-row');
    for (const row of rows) {
      if (row.dataset.cardId === cardId) {
        row.classList.add('is-selected');
        row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }
    }
  }

  function clearLeaderboardSelection() {
    const rows = document.querySelectorAll('.leaderboard-row.is-selected');
    for (const row of rows) row.classList.remove('is-selected');
  }

  function renderBarOverview(barOverview) {
    document.getElementById('bar-distinct-products').textContent =
      formatNumber(barOverview.distinct_high_btw_products);
    document.getElementById('bar-total-ordered').textContent =
      formatNumber(barOverview.total_drinks_ordered);

    const ul = document.getElementById('bar-busiest-list');
    ul.innerHTML = '';
    for (const drink of barOverview.busiest_drinks) {
      const li = document.createElement('li');
      li.className = 'busiest-drink-row';
      const name = document.createElement('span');
      name.className = 'busiest-drink-row__name';
      name.textContent = drink.product;
      const count = document.createElement('span');
      count.className = 'busiest-drink-row__count';
      count.textContent = formatNumber(drink.count);
      li.append(name, count);
      ul.appendChild(li);
    }
  }

  function formatNumber(n) {
    return new Intl.NumberFormat('en-US').format(n);
  }

  // ───── Card stats panel + Club van 1000 ─────────────────────────────────────

  /**
   * Fill the individual-stats panel for a card. Does NOT touch the hero graph
   * or the leaderboard highlight — those belong to selectCard().
   */
  function populateIndividualStats(card) {
    document.getElementById('card-search-input').value = card.display_label;
    document.getElementById('card-stats-card-id').textContent = card.display_label;
    document.getElementById('card-stats-total').textContent = formatNumber(card.total_drinks);
    document.getElementById('card-stats-borrels').textContent = formatNumber(card.borrels_attended);
    document.getElementById('card-record-wobo').textContent = formatNumber(card.longest_wobo_streak);
    document.getElementById('card-record-vrimibo').textContent = formatNumber(card.longest_vrimibo_streak);

    renderClubVan1000(card);
    renderDistributionChart(card.drink_distribution);
    renderWeekdayChart(card.weekday_attendance);

    document.getElementById('card-stats-panel').classList.remove('is-hidden');
    document.getElementById('card-not-found').classList.add('is-hidden');
  }

  function hideCardStats() {
    document.getElementById('card-stats-panel').classList.add('is-hidden');
    destroyIfExists('distribution');
    destroyIfExists('weekday');
  }

  function showCardNotFound() {
    hideCardStats();
    document.getElementById('card-not-found').classList.remove('is-hidden');
  }

  function clearCardNotFound() {
    document.getElementById('card-not-found').classList.add('is-hidden');
  }

  /** Compute the Club van 1000 figures and update the dedicated DOM nodes. */
  function renderClubVan1000(card) {
    const daysElapsed = daysBetweenInclusive(state.seasonBounds.start, state.today);
    const daysTotal = daysBetweenInclusive(state.seasonBounds.start, state.seasonBounds.endInclusive);

    const expectedToday = Math.round((daysElapsed / daysTotal) * SEASON_TARGET_DRINKS);
    const deviation = card.total_drinks - expectedToday;
    const dailyPace = card.total_drinks / daysElapsed;
    const projected = Math.round(dailyPace * daysTotal);

    document.getElementById('card-club-expected').textContent = formatNumber(expectedToday);
    document.getElementById('card-club-deviation').textContent = formatSignedNumber(deviation);

    const deviationCol = document.querySelector('#card-club-1000 .club1000__deviation-col');
    if (deviationCol) {
      deviationCol.classList.remove('club1000__deviation-col--ahead', 'club1000__deviation-col--behind');
      deviationCol.classList.add(deviation >= 0
        ? 'club1000__deviation-col--ahead'
        : 'club1000__deviation-col--behind');
    }

    const deviationLabel = document.querySelector('#card-club-1000 .club1000__deviation-label');
    if (deviationLabel) {
      if (deviation > 0) deviationLabel.textContent = 'ahead of schedule';
      else if (deviation < 0) deviationLabel.textContent = 'behind schedule';
      else deviationLabel.textContent = 'on schedule';
    }

    document.getElementById('card-club-projection').textContent =
      buildProjectionLabel(card.total_drinks, dailyPace, projected);
  }

  function formatSignedNumber(value) {
    if (value >= 0) return '+' + formatNumber(value);
    return MINUS_SIGN + formatNumber(Math.abs(value));
  }

  function buildProjectionLabel(currentDrinks, dailyPace, projected) {
    if (currentDrinks >= SEASON_TARGET_DRINKS) {
      return `Already in the Club van 1000 \u2014 ${formatNumber(currentDrinks)} drinks and counting.`;
    }
    if (dailyPace <= 0 || !isFinite(dailyPace)) {
      return 'No qualifying drinks yet \u2014 pace cannot be projected.';
    }
    if (projected >= SEASON_TARGET_DRINKS) {
      const remaining = SEASON_TARGET_DRINKS - currentDrinks;
      const daysToTarget = Math.ceil(remaining / dailyPace);
      const targetDate = addDays(startOfDay(state.today), daysToTarget);
      return `On track to reach 1 000 on ${formatHumanDate(targetDate)}.`;
    }
    return `Projected to reach \u2248 ${formatNumber(projected)} by 31 Aug \u2014 target out of reach at current pace.`;
  }

  // ───── Card selection (single source of truth for "show this card") ─────────

  /**
   * Activate the per-card view: hero graph, individual stats panel, search
   * input, leaderboard highlight. Used by both the leaderboard click handler
   * and the search button.
   */
  function selectCard(cardId) {
    const card = state.aggregated.cards[cardId];
    if (!card) {
      showCardNotFound();
      return;
    }
    clearCardNotFound();
    populateIndividualStats(card);
    renderPerCardHero(card);
    highlightLeaderboardRow(cardId);
  }

  // ───── Card search ──────────────────────────────────────────────────────────

  /**
   * Resolve a query to a single card.
   *   1) Exact match on raw card_id.
   *   2) Case-insensitive substring on display_label; among ties, pick the
   *      card with the highest total_drinks.
   * Returns null when nothing matches.
   */
  function resolveCard(query, cards) {
    const trimmed = (query || '').trim();
    if (!trimmed) return null;

    if (cards[trimmed]) return cards[trimmed];

    const needle = trimmed.toLowerCase();
    let best = null;
    for (const cardId in cards) {
      const card = cards[cardId];
      const label = card.display_label.toLowerCase();
      if (label.includes(needle)) {
        if (!best || card.total_drinks > best.total_drinks) {
          best = card;
        }
      }
    }
    // TODO: when multiple cards match by name, surface a disambiguation UI
    //       instead of silently picking the highest-ranked one.
    return best;
  }

  function wireCardSearch() {
    const input = document.getElementById('card-search-input');
    const button = document.getElementById('card-search-button');

    function performSearch() {
      const card = resolveCard(input.value, state.aggregated.cards);
      if (card) {
        selectCard(card.card_id);
      } else {
        showCardNotFound();
      }
    }

    button.addEventListener('click', performSearch);
    input.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        performSearch();
      }
    });
  }

  // ───── Loading: silent fetch + file-picker fallback ─────────────────────────

  /**
   * Try fetching both CSVs from the same origin. Returns null on failure
   * instead of throwing, so the password gate can run in parallel and fall
   * back to a file picker only after the user has unlocked.
   */
  function tryFetchSilently() {
    const fetchOrNull = (url) => fetch(url)
      .then((r) => r.ok ? r.text() : null)
      .catch(() => null);
    return Promise.all([
      fetchOrNull('./master_data.csv'),
      fetchOrNull('./rekeningen.csv')
    ]).then(([m, r]) => (m && r) ? [m, r] : null);
  }

  function promptForFiles() {
    return new Promise((resolve) => {
      const wrap = document.createElement('div');
      wrap.style.cssText =
        'position:fixed;inset:0;background:#f3e7c9;z-index:200;' +
        'display:flex;flex-direction:column;align-items:center;justify-content:center;' +
        'gap:1rem;font-family:system-ui,sans-serif;color:#2b1a10;padding:2rem;text-align:center;';
      wrap.innerHTML = `
        <h2 style="font-family:'DM Serif Display',serif;margin:0;">Select your data files</h2>
        <p style="max-width:480px;margin:0;">
          The page can't fetch CSVs directly when opened from disk. Pick both files to continue.
        </p>
        <label style="display:flex;flex-direction:column;gap:0.25rem;">
          master_data.csv <input id="picker-master" type="file" accept=".csv">
        </label>
        <label style="display:flex;flex-direction:column;gap:0.25rem;">
          rekeningen.csv <input id="picker-rekeningen" type="file" accept=".csv">
        </label>
        <button id="picker-go" style="padding:0.5rem 1.25rem;background:#6b3e26;color:#f3e7c9;border:none;cursor:pointer;font-weight:600;">
          Load
        </button>
      `;
      document.body.appendChild(wrap);
      document.getElementById('picker-go').addEventListener('click', async () => {
        const masterFile = document.getElementById('picker-master').files[0];
        const rekeningenFile = document.getElementById('picker-rekeningen').files[0];
        if (!masterFile || !rekeningenFile) {
          alert('Please pick both files.');
          return;
        }
        const [masterText, rekeningenText] = await Promise.all([
          masterFile.text(),
          rekeningenFile.text()
        ]);
        document.body.removeChild(wrap);
        resolve([masterText, rekeningenText]);
      });
    });
  }

  // ───── Password gate ────────────────────────────────────────────────────────

  /**
   * Inject and display the password gate. Resolves when the user enters the
   * correct password. The dashboard is unreadable behind the gate; the gate
   * itself does not block the data fetch happening in parallel.
   */
  function showPasswordGate() {
    return new Promise((resolve) => {
      const gate = document.createElement('div');
      gate.id = 'password-gate';
      gate.className = 'gate';
      gate.innerHTML = `
        <div class="gate__stripe" aria-hidden="true">
          <span></span><span></span><span></span>
        </div>
        <h1 class="gate__title">de <em>Atmosfeer</em></h1>
        <p class="gate__sub">Enter the secret word to view the bar stats.</p>
        <form class="gate__form" id="gate-form" autocomplete="off">
          <input
            id="gate-input"
            class="gate__input"
            type="password"
            placeholder="Password"
            aria-label="Password"
            autofocus
          >
          <button class="gate__button" type="submit">Unlock</button>
          <p class="gate__error" id="gate-error" aria-live="polite"></p>
        </form>
      `;
      document.body.appendChild(gate);

      const form = document.getElementById('gate-form');
      const input = document.getElementById('gate-input');
      const errorEl = document.getElementById('gate-error');

      // Defer focus so the autofocus attribute resolves first on slower browsers.
      setTimeout(() => input.focus(), 0);

      form.addEventListener('submit', (event) => {
        event.preventDefault();
        const value = input.value.trim().toLowerCase();
        if (value === PASSWORD) {
          gate.remove();
          resolve();
        } else {
          errorEl.textContent = 'Wrong word. Try again.';
          gate.classList.remove('gate--shake');
          // Reflow so the animation can replay on repeated wrong attempts.
          void gate.offsetWidth;
          gate.classList.add('gate--shake');
          input.select();
        }
      });
    });
  }

  // ───── Init ─────────────────────────────────────────────────────────────────

  async function main() {
    try {
      assertRequiredDomIds();
    } catch (e) {
      showErrorBanner(e.message);
      console.error(e);
      return;
    }

    // Hide any leftover mock content right away so it doesn't flash if the
    // password gate somehow fails to inject.
    hideCardStats();
    clearCardNotFound();
    setLoadingOverlayVisible(false);

    // Kick off the silent fetch in parallel with the password gate so users
    // who type the password slowly land directly on rendered data.
    const dataPromise = tryFetchSilently();

    try {
      await showPasswordGate();
    } catch (e) {
      showErrorBanner('Gate error: ' + e.message);
      console.error(e);
      return;
    }

    // Trigger the section reveal animations now that the gate is gone.
    document.body.classList.add('is-revealed');

    setLoadingOverlayVisible(true);
    clearErrorBanner();

    let masterText;
    let rekeningenText;
    try {
      const fetched = await dataPromise;
      if (fetched) {
        [masterText, rekeningenText] = fetched;
      } else {
        // Same-origin fetch failed; fall back to the file picker now.
        [masterText, rekeningenText] = await promptForFiles();
      }
    } catch (e) {
      setLoadingOverlayVisible(false);
      showErrorBanner('Could not load data files: ' + e.message);
      console.error(e);
      return;
    }

    try {
      const nameMap = parseRekeningenIntoNameMap(rekeningenText);
      const allRows = parseMasterData(masterText);

      const today = new Date();
      const seasonBounds = currentSeasonBounds(today);
      const qualifies = makeQualifier(seasonBounds.start);
      const qualifyingRows = allRows.filter(qualifies);

      const aggregated = aggregateAll(qualifyingRows, seasonBounds.start, today, nameMap);
      aggregated.meta.season_label = seasonBounds.label;

      const dataTimestamp = findLatestDataTimestamp(allRows);

      // Park results in module state so click handlers can find them.
      state.seasonBounds = seasonBounds;
      state.today = today;
      state.aggregated = aggregated;

      console.info(
        `[bar-stats] season=${seasonBounds.label} ` +
        `qualifying_rows=${qualifyingRows.length} ` +
        `total_drinks=${aggregated.bar_overview.total_drinks_ordered} ` +
        `unique_cards=${aggregated.leaderboard.length}`
      );

      renderMeta(seasonBounds, dataTimestamp);
      renderLeaderboard(aggregated.leaderboard, selectCard);
      renderBarOverview(aggregated.bar_overview);
      ensureResetButton();
      renderBarWideHero();          // initial hero graph (all-bar mode)
      wireCardSearch();

      // Auto-fill individual stats with the leaderboard #1 so the section
      // isn't empty on first load. The hero graph stays in all-bar mode and
      // no leaderboard row is highlighted — the user has not actively picked
      // anyone yet.
      if (aggregated.leaderboard.length > 0) {
        const topCardId = aggregated.leaderboard[0].card_id;
        const topCard = aggregated.cards[topCardId];
        if (topCard) populateIndividualStats(topCard);
      }
    } catch (e) {
      showErrorBanner('Failed to process data: ' + e.message);
      console.error(e);
    } finally {
      setLoadingOverlayVisible(false);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', main);
  } else {
    main();
  }
})();